# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.
# Developed by Upstackers Technologies

from . import ust_slider_snippets
from . import ust_product_template
